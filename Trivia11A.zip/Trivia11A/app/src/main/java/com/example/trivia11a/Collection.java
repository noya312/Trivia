package com.example.trivia11a;public class Collection {
}
